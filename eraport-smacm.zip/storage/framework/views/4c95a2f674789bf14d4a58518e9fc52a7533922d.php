<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Student Weekly Report</title>

    <script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <style>
        .page-break{
            page-break-after: always;
        }
    </style>
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<!-- App favicon -->
	<link rel="shortcut icon" href="/assets/images/favicon-cendekia.jpg">
	<!-- Bootstrap Css -->
	<link href="/assets/css/bootstrap.min.css" id="bootstrap-style" rel="stylesheet" type="text/css" />
	<!-- Icons Css -->
	<link href="/assets/css/icons.min.css" rel="stylesheet" type="text/css" />
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.5.0/font/bootstrap-icons.css">
	<!-- App Css-->
	<link href="/assets/css/app.min.css" id="app-style" rel="stylesheet" type="text/css" />
	<link href="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/css/select2.min.css" rel="stylesheet" />
</head>
<body style="background-color: white">
    <div class="container" id="jadi">
        
                
                        
                    

    <div class="row mt-5 mx-auto">
        <div class="col-lg-12">
                    <div class="invoice-title">
                        <div class="mb-4">
                            <img src="/assets/images/SMA.png" alt="logo" height="50"/>
                        </div>
                        <div class="text-center">
                            <h6><b>Student Weekly Report</b></h6>
                            <h6><b>SMA Islam Cendekia Muda</b></h6>
                        </div>
                        <div class="text-muted">
                            <h6 class="mb-1">
                                <b>Nama :</b>   <?php $__currentLoopData = $datasiswa; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <?php echo e($item['nama']); ?>

                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </h6>
                            
                        </div>
                    </div>
    
                    <hr class="my-4">
                    
                    <div class="py-2">
                        <h5 class="font-size-15">Laporan Murabbi</h5>
    
                        <div class="table-responsive">
                            <table class="table table-nowrap table-centered mb-0">
                                <thead>
                                    <tr>
                                        <th>Ibadah yang Masih Harus Diperbaiki</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <tr>
                                        <td>
                                            <h5 class="font-size-15 mb-1">
                                                <?php $__currentLoopData = $datasiswa; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <?php $__currentLoopData = $item['ibadah_yang_masih_harus_diperbaiki']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <ul>
                                                        <li><?php echo e($val); ?></li>
                                                    </ul>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </h5>
                                        </td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>
    
                        <div class="table-responsive">
                            <table class="table table-nowrap table-centered mb-0">
                                <thead>
                                    <tr>
                                        <th>Interaksi Dengan Orangtua (Birrul Walidain) yang Masih Harus Diperbaiki</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <tr>
                                        <td>
                                            <h5 class="font-size-15 mb-1">
                                                <?php $__currentLoopData = $datasiswa; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <?php $__currentLoopData = $item['birrul_walidain']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <ul>
                                                        <li><?php echo e($val); ?></li>
                                                    </ul>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </h5>
                                        </td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>
    
                        <div class="table-responsive">
                            <table class="table table-nowrap table-centered mb-0">
                                <thead>
                                    <tr>
                                        <th>Tugas/UH/Ujian/Keterampilan yang Masih Belum Terpenuhi di Mata Pelajaran</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <tr>
                                        <td>
                                            <h5 class="font-size-15 mb-1">
                                                <?php $__currentLoopData = $datasiswa; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <?php $__currentLoopData = $item['tanggung_jawab_terhadap_matapelajaran']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <ul>
                                                        <li><?php echo e($val); ?></li>
                                                    </ul>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </h5>
                                        </td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>
    
                        <div class="page-break"></div>
    
                        
                        <div class="row mb-5 mx-auto">
                            <div class="col-xl-4">
                                
                                <p><b> Grafik Menjaga dan Menyempurnakan Wudhu </b></p>
                                <div>
                                    <canvas id="Chart"></canvas>
                                    
                                </div>
                            </div>
                            <!-- end col -->
                            <div class="col-xl-4">
                                
                                <p><b> Grafik Sholat Wajib </b></p>
                                <div>
                                    <canvas id="Chart2"></canvas>
                                </div>
                            </div>
                            <!-- end col -->
                            <div class="col-xl-4">
                                
                                <p><b> Grafik Sholat Rawatib </b></p>
                                <div>
                                    <canvas id="Chart3"></canvas>
                                </div>
                            </div>
                        </div>

                        <div class="page-break"></div>

                        <div class="row mb-5 mx-auto">
                            <!-- end col -->
                            <div class="col-xl-4">
                                
                                <p><b> Grafik Sholat Sunnah </b></p>
                                <div>
                                    <canvas id="Chart4"></canvas>
                                </div>
                            </div>
                            <!-- end col -->
                            <div class="col-xl-4">
                                
                                <p><b> Grafik Shaum </b></p>
                                <div>
                                    <canvas id="Chart5"></canvas>
                                </div>
                            </div>
                            <!-- end col -->
                            <div class="col-xl-4">
                                
                                <p><b> Grafik Quran </b></p>
                                <div>
                                    <canvas id="Chart6"></canvas>
                                </div>
                            </div>
                            <!-- end col -->
                        </div>
                        <div class="row mb-5 mx-auto">
                        </div>

                        <div class="page-break"></div>

                        <div class="row mb-5 mx-auto">
                            <div class="col-xl-4">
                                
                                <p><b> Grafik Infaq dan Shodaqoh </b></p>
                                <div>
                                    <canvas id="Chart7"></canvas>
                                </div>
                            </div>
                            <!-- end col -->
                            <div class="col-xl-4">
                                
                                <p><b> Grafik Dzikir </b></p>
                                <div>
                                    <canvas id="Chart8"></canvas>
                                </div>
                            </div>
                            <!-- end col -->
                            <div class="col-xl-4">
                                <p><b> Grafik Nilai Total </b></p>
                                <div>
                                    <canvas id="Chart9"></canvas>
                                    
                                </div>
                            </div>
                        </div>
                        
                    </div>
                </div>
    </div>
</div>
    
    
    <script type="text/javascript">

            

            var ctx = document.getElementById("Chart").getContext("2d");
            var myChart = new Chart(ctx, {
                type: "line",
                data: {
                    
                    labels: [
                        <?php $__currentLoopData = $datamutabaah; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                "<?php echo e($value["tanggal"]); ?>",
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    ],
                    datasets: [{
                        label: "Menjaga dan Menyempurnakan Wudhu",
                        data: [
                            <?php $__currentLoopData = $datamutabaah; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                "<?php echo e($value["menjaga_menyempurnakan_wudhu"]); ?>",
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        ],
                        backgroundColor: [
                            "rgba(255, 99, 132, 0.2)",
                            "rgba(54, 162, 235, 0.2)",
                            "rgba(255, 206, 86, 0.2)",
                            "rgba(75, 192, 192, 0.2)",
                            "rgba(153, 102, 255, 0.2)",
                            "rgba(255, 159, 64, 0.2)"
                        ],
                        borderColor: [
                            "rgba(255, 99, 132, 1)",
                            "rgba(54, 162, 235, 1)",
                            "rgba(255, 206, 86, 1)",
                            "rgba(75, 192, 192, 1)",
                            "rgba(153, 102, 255, 1)",
                            "rgba(255, 159, 64, 1)"
                        ],
                        borderWidth: 1
                    }]
                },
                options: {
                    scales: {
                        y: {
                            beginAtZero: true
                        }
                    }
                }
            });
            // var img1 = myChart.toBase64Image();
            // document.getElementById('contoh').src(img1);
            // console.log(img1);
            // var chartjsToImage = require("chartjs-to-image")
            // const myChart15 = new ChartJsImage();
            //     myChart15.setConfig({
            //     type: 'bar',
            //     data: { labels: ['Hello world', 'Foo bar'], datasets: [{ label: 'Foo', data: [1, 2] }] },
            //     });
            // const dataUrl = await myChart.toDataUrl();
            // console.log(myChart15.getUrl());
    
            var ctx2 = document.getElementById("Chart2").getContext("2d");
            var myChart2 = new Chart(ctx2, {
                type: "line",
                data: {
                    labels: [
                        <?php $__currentLoopData = $datamutabaah; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                "<?php echo e($value["tanggal"]); ?>",
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    ],
                    datasets: [{
                        label: "Sholat Subuh",
                        data: [
                                <?php $__currentLoopData = $datamutabaah; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                "<?php echo e($value["sholat_subuh"]); ?>",
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
                        ],
                        backgroundColor: [
                            "rgba(255, 99, 132, 0.2)",
                            "rgba(54, 162, 235, 0.2)",
                            "rgba(255, 206, 86, 0.2)",
                            "rgba(75, 192, 192, 0.2)",
                            "rgba(153, 102, 255, 0.2)",
                            "rgba(255, 159, 64, 0.2)"
                        ],
                        borderColor: [
                            "rgba(255, 99, 132, 1)",
                            "rgba(54, 162, 235, 1)",
                            "rgba(255, 206, 86, 1)",
                            "rgba(75, 192, 192, 1)",
                            "rgba(153, 102, 255, 1)",
                            "rgba(255, 159, 64, 1)"
                        ],
                        borderWidth: 1
                    },
                    {
                        label: "Sholat Dzuhur",
                        data: [
                                <?php $__currentLoopData = $datamutabaah; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                "<?php echo e($value["sholat_dzuhur"]); ?>",
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
                        ],
                        backgroundColor: [
                            "rgba(255, 99, 132, 0.2)",
                            "rgba(54, 162, 235, 0.2)",
                            "rgba(255, 206, 86, 0.2)",
                            "rgba(75, 192, 192, 0.2)",
                            "rgba(153, 102, 255, 0.2)",
                            "rgba(255, 159, 64, 0.2)"
                        ],
                        borderColor: [
                            "rgba(255, 99, 132, 1)",
                            "rgba(54, 162, 235, 1)",
                            "rgba(255, 206, 86, 1)",
                            "rgba(75, 192, 192, 1)",
                            "rgba(153, 102, 255, 1)",
                            "rgba(255, 159, 64, 1)"
                        ],
                        borderWidth: 1
                    },
                    {
                        label: "Sholat Ashar",
                        data: [
                                <?php $__currentLoopData = $datamutabaah; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                "<?php echo e($value["sholat_ashar"]); ?>",
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
                        ],
                        backgroundColor: [
                            "rgba(255, 99, 132, 0.2)",
                            "rgba(54, 162, 235, 0.2)",
                            "rgba(255, 206, 86, 0.2)",
                            "rgba(75, 192, 192, 0.2)",
                            "rgba(153, 102, 255, 0.2)",
                            "rgba(255, 159, 64, 0.2)"
                        ],
                        borderColor: [
                            "rgba(255, 99, 132, 1)",
                            "rgba(54, 162, 235, 1)",
                            "rgba(255, 206, 86, 1)",
                            "rgba(75, 192, 192, 1)",
                            "rgba(153, 102, 255, 1)",
                            "rgba(255, 159, 64, 1)"
                        ],
                        borderWidth: 1
                    },
                    {
                        label: "Sholat Maghrib",
                        data: [
                                <?php $__currentLoopData = $datamutabaah; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                "<?php echo e($value["sholat_maghrib"]); ?>",
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
                        ],
                        backgroundColor: [
                            "rgba(255, 99, 132, 0.2)",
                            "rgba(54, 162, 235, 0.2)",
                            "rgba(255, 206, 86, 0.2)",
                            "rgba(75, 192, 192, 0.2)",
                            "rgba(153, 102, 255, 0.2)",
                            "rgba(255, 159, 64, 0.2)"
                        ],
                        borderColor: [
                            "rgba(255, 99, 132, 1)",
                            "rgba(54, 162, 235, 1)",
                            "rgba(255, 206, 86, 1)",
                            "rgba(75, 192, 192, 1)",
                            "rgba(153, 102, 255, 1)",
                            "rgba(255, 159, 64, 1)"
                        ],
                        borderWidth: 1
                    },
                    {
                        label: "Sholat Isya",
                        data: [
                                <?php $__currentLoopData = $datamutabaah; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                "<?php echo e($value["sholat_isya"]); ?>",
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
                        ],
                        backgroundColor: [
                            "rgba(255, 99, 132, 0.2)",
                            "rgba(54, 162, 235, 0.2)",
                            "rgba(255, 206, 86, 0.2)",
                            "rgba(75, 192, 192, 0.2)",
                            "rgba(153, 102, 255, 0.2)",
                            "rgba(255, 159, 64, 0.2)"
                        ],
                        borderColor: [
                            "rgba(255, 99, 132, 1)",
                            "rgba(54, 162, 235, 1)",
                            "rgba(255, 206, 86, 1)",
                            "rgba(75, 192, 192, 1)",
                            "rgba(153, 102, 255, 1)",
                            "rgba(255, 159, 64, 1)"
                        ],
                        borderWidth: 1
                    }],
                },
                options: {
                    scales: {
                        y: {
                            beginAtZero: true
                        }
                    }
                }
            });
    
            // Start of Grafik Sholat Rawatib
            var ctx3 = document.getElementById("Chart3").getContext("2d");
            var myChart3 = new Chart(ctx3, {
                type: "line",
                data: {
                    labels: [
                        <?php $__currentLoopData = $datamutabaah; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                "<?php echo e($value["tanggal"]); ?>",
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    ],
                    datasets: [{
                        label: "Rawatib Subuh",
                        data: [
                                <?php $__currentLoopData = $datamutabaah; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                "<?php echo e($value["rawatib_subuh"]); ?>",
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
                        ],
                        backgroundColor: [
                            "rgba(255, 99, 132, 0.2)",
                            "rgba(54, 162, 235, 0.2)",
                            "rgba(255, 206, 86, 0.2)",
                            "rgba(75, 192, 192, 0.2)",
                            "rgba(153, 102, 255, 0.2)",
                            "rgba(255, 159, 64, 0.2)"
                        ],
                        borderColor: [
                            "rgba(255, 99, 132, 1)",
                            "rgba(54, 162, 235, 1)",
                            "rgba(255, 206, 86, 1)",
                            "rgba(75, 192, 192, 1)",
                            "rgba(153, 102, 255, 1)",
                            "rgba(255, 159, 64, 1)"
                        ],
                        borderWidth: 1
                    },
                    {
                        label: "Rawatib Dzuhur",
                        data: [
                                <?php $__currentLoopData = $datamutabaah; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                "<?php echo e($value["rawatib_dzuhur"]); ?>",
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
                        ],
                        backgroundColor: [
                            "rgba(255, 99, 132, 0.2)",
                            "rgba(54, 162, 235, 0.2)",
                            "rgba(255, 206, 86, 0.2)",
                            "rgba(75, 192, 192, 0.2)",
                            "rgba(153, 102, 255, 0.2)",
                            "rgba(255, 159, 64, 0.2)"
                        ],
                        borderColor: [
                            "rgba(255, 99, 132, 1)",
                            "rgba(54, 162, 235, 1)",
                            "rgba(255, 206, 86, 1)",
                            "rgba(75, 192, 192, 1)",
                            "rgba(153, 102, 255, 1)",
                            "rgba(255, 159, 64, 1)"
                        ],
                        borderWidth: 1
                    },
                    {
                        label: "Rawatib Ashar",
                        data: [
                                <?php $__currentLoopData = $datamutabaah; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                "<?php echo e($value["rawatib_ashar"]); ?>",
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
                        ],
                        backgroundColor: [
                            "rgba(255, 99, 132, 0.2)",
                            "rgba(54, 162, 235, 0.2)",
                            "rgba(255, 206, 86, 0.2)",
                            "rgba(75, 192, 192, 0.2)",
                            "rgba(153, 102, 255, 0.2)",
                            "rgba(255, 159, 64, 0.2)"
                        ],
                        borderColor: [
                            "rgba(255, 99, 132, 1)",
                            "rgba(54, 162, 235, 1)",
                            "rgba(255, 206, 86, 1)",
                            "rgba(75, 192, 192, 1)",
                            "rgba(153, 102, 255, 1)",
                            "rgba(255, 159, 64, 1)"
                        ],
                        borderWidth: 1
                    },
                    {
                        label: "Rawatib Maghrib",
                        data: [
                                <?php $__currentLoopData = $datamutabaah; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                "<?php echo e($value["rawatib_maghrib"]); ?>",
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
                        ],
                        backgroundColor: [
                            "rgba(255, 99, 132, 0.2)",
                            "rgba(54, 162, 235, 0.2)",
                            "rgba(255, 206, 86, 0.2)",
                            "rgba(75, 192, 192, 0.2)",
                            "rgba(153, 102, 255, 0.2)",
                            "rgba(255, 159, 64, 0.2)"
                        ],
                        borderColor: [
                            "rgba(255, 99, 132, 1)",
                            "rgba(54, 162, 235, 1)",
                            "rgba(255, 206, 86, 1)",
                            "rgba(75, 192, 192, 1)",
                            "rgba(153, 102, 255, 1)",
                            "rgba(255, 159, 64, 1)"
                        ],
                        borderWidth: 1
                    },
                    {
                        label: "Rawatib Isya",
                        data: [
                                <?php $__currentLoopData = $datamutabaah; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                "<?php echo e($value["rawatib_isya"]); ?>",
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
                        ],
                        backgroundColor: [
                            "rgba(255, 99, 132, 0.2)",
                            "rgba(54, 162, 235, 0.2)",
                            "rgba(255, 206, 86, 0.2)",
                            "rgba(75, 192, 192, 0.2)",
                            "rgba(153, 102, 255, 0.2)",
                            "rgba(255, 159, 64, 0.2)"
                        ],
                        borderColor: [
                            "rgba(255, 99, 132, 1)",
                            "rgba(54, 162, 235, 1)",
                            "rgba(255, 206, 86, 1)",
                            "rgba(75, 192, 192, 1)",
                            "rgba(153, 102, 255, 1)",
                            "rgba(255, 159, 64, 1)"
                        ],
                        borderWidth: 1
                    }],
                },
                options: {
                    scales: {
                        y: {
                            beginAtZero: true
                        }
                    }
                }
            });
            // End of Grafik Sholat Rawatib
    
            // Start of Grafik Sholat Sunnah
            var ctx4 = document.getElementById("Chart4").getContext("2d");
            var myChart4 = new Chart(ctx4, {
                type: "line",
                data: {
                    labels: [
                        <?php $__currentLoopData = $datamutabaah; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                "<?php echo e($value["tanggal"]); ?>",
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    ],
                    datasets: [{
                        label: "Dhuha",
                        data: [
                                <?php $__currentLoopData = $datamutabaah; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                "<?php echo e($value["dhuha"]); ?>",
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
                        ],
                        backgroundColor: [
                            "rgba(255, 99, 132, 0.2)",
                            "rgba(54, 162, 235, 0.2)",
                            "rgba(255, 206, 86, 0.2)",
                            "rgba(75, 192, 192, 0.2)",
                            "rgba(153, 102, 255, 0.2)",
                            "rgba(255, 159, 64, 0.2)"
                        ],
                        borderColor: [
                            "rgba(255, 99, 132, 1)",
                            "rgba(54, 162, 235, 1)",
                            "rgba(255, 206, 86, 1)",
                            "rgba(75, 192, 192, 1)",
                            "rgba(153, 102, 255, 1)",
                            "rgba(255, 159, 64, 1)"
                        ],
                        borderWidth: 1
                    },
                    {
                        label: "Tahajud",
                        data: [
                                <?php $__currentLoopData = $datamutabaah; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                "<?php echo e($value["tahajud"]); ?>",
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
                        ],
                        backgroundColor: [
                            "rgba(255, 99, 132, 0.2)",
                            "rgba(54, 162, 235, 0.2)",
                            "rgba(255, 206, 86, 0.2)",
                            "rgba(75, 192, 192, 0.2)",
                            "rgba(153, 102, 255, 0.2)",
                            "rgba(255, 159, 64, 0.2)"
                        ],
                        borderColor: [
                            "rgba(255, 99, 132, 1)",
                            "rgba(54, 162, 235, 1)",
                            "rgba(255, 206, 86, 1)",
                            "rgba(75, 192, 192, 1)",
                            "rgba(153, 102, 255, 1)",
                            "rgba(255, 159, 64, 1)"
                        ],
                        borderWidth: 1
                    },
                    {
                        label: "Witir",
                        data: [
                                <?php $__currentLoopData = $datamutabaah; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                "<?php echo e($value["witir"]); ?>",
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
                        ],
                        backgroundColor: [
                            "rgba(255, 99, 132, 0.2)",
                            "rgba(54, 162, 235, 0.2)",
                            "rgba(255, 206, 86, 0.2)",
                            "rgba(75, 192, 192, 0.2)",
                            "rgba(153, 102, 255, 0.2)",
                            "rgba(255, 159, 64, 0.2)"
                        ],
                        borderColor: [
                            "rgba(255, 99, 132, 1)",
                            "rgba(54, 162, 235, 1)",
                            "rgba(255, 206, 86, 1)",
                            "rgba(75, 192, 192, 1)",
                            "rgba(153, 102, 255, 1)",
                            "rgba(255, 159, 64, 1)"
                        ],
                        borderWidth: 1
                    },
                    {
                        label: "Tarawih",
                        data: [
                                <?php $__currentLoopData = $datamutabaah; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                "<?php echo e($value["tarawih"]); ?>",
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
                        ],
                        backgroundColor: [
                            "rgba(255, 99, 132, 0.2)",
                            "rgba(54, 162, 235, 0.2)",
                            "rgba(255, 206, 86, 0.2)",
                            "rgba(75, 192, 192, 0.2)",
                            "rgba(153, 102, 255, 0.2)",
                            "rgba(255, 159, 64, 0.2)"
                        ],
                        borderColor: [
                            "rgba(255, 99, 132, 1)",
                            "rgba(54, 162, 235, 1)",
                            "rgba(255, 206, 86, 1)",
                            "rgba(75, 192, 192, 1)",
                            "rgba(153, 102, 255, 1)",
                            "rgba(255, 159, 64, 1)"
                        ],
                        borderWidth: 1
                    },
                    {
                        label: "Lainnya",
                        data: [
                                <?php $__currentLoopData = $datamutabaah; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                "<?php echo e($value["sholat_sunnah_lainnya"]); ?>",
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
                        ],
                        backgroundColor: [
                            "rgba(255, 99, 132, 0.2)",
                            "rgba(54, 162, 235, 0.2)",
                            "rgba(255, 206, 86, 0.2)",
                            "rgba(75, 192, 192, 0.2)",
                            "rgba(153, 102, 255, 0.2)",
                            "rgba(255, 159, 64, 0.2)"
                        ],
                        borderColor: [
                            "rgba(255, 99, 132, 1)",
                            "rgba(54, 162, 235, 1)",
                            "rgba(255, 206, 86, 1)",
                            "rgba(75, 192, 192, 1)",
                            "rgba(153, 102, 255, 1)",
                            "rgba(255, 159, 64, 1)"
                        ],
                        borderWidth: 1
                    }],
                },
                options: {
                    scales: {
                        y: {
                            beginAtZero: true
                        }
                    }
                }
            });
            // End of Grafik Sholat Sunnah
    
            // Start of Grafik Shaum
            var ctx5 = document.getElementById("Chart5").getContext("2d");
            var myChart5 = new Chart(ctx5, {
                type: "line",
                data: {
                    labels: [
                        <?php $__currentLoopData = $datamutabaah; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                "<?php echo e($value["tanggal"]); ?>",
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    ],
                    datasets: [{
                        label: "Senin/Kamis",
                        data: [
                                <?php $__currentLoopData = $datamutabaah; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                "<?php echo e($value["shaum_senin_kamis"]); ?>",
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
                        ],
                        backgroundColor: [
                            "rgba(255, 99, 132, 0.2)",
                            "rgba(54, 162, 235, 0.2)",
                            "rgba(255, 206, 86, 0.2)",
                            "rgba(75, 192, 192, 0.2)",
                            "rgba(153, 102, 255, 0.2)",
                            "rgba(255, 159, 64, 0.2)"
                        ],
                        borderColor: [
                            "rgba(255, 99, 132, 1)",
                            "rgba(54, 162, 235, 1)",
                            "rgba(255, 206, 86, 1)",
                            "rgba(75, 192, 192, 1)",
                            "rgba(153, 102, 255, 1)",
                            "rgba(255, 159, 64, 1)"
                        ],
                        borderWidth: 1
                    },
                    {
                        label: "Dawud",
                        data: [
                                <?php $__currentLoopData = $datamutabaah; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                "<?php echo e($value["shaum_dawud"]); ?>",
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
                        ],
                        backgroundColor: [
                            "rgba(255, 99, 132, 0.2)",
                            "rgba(54, 162, 235, 0.2)",
                            "rgba(255, 206, 86, 0.2)",
                            "rgba(75, 192, 192, 0.2)",
                            "rgba(153, 102, 255, 0.2)",
                            "rgba(255, 159, 64, 0.2)"
                        ],
                        borderColor: [
                            "rgba(255, 99, 132, 1)",
                            "rgba(54, 162, 235, 1)",
                            "rgba(255, 206, 86, 1)",
                            "rgba(75, 192, 192, 1)",
                            "rgba(153, 102, 255, 1)",
                            "rgba(255, 159, 64, 1)"
                        ],
                        borderWidth: 1
                    },
                    {
                        label: "Ramadhan",
                        data: [
                                <?php $__currentLoopData = $datamutabaah; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                "<?php echo e($value["shaum_ramadhan"]); ?>",
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
                        ],
                        backgroundColor: [
                            "rgba(255, 99, 132, 0.2)",
                            "rgba(54, 162, 235, 0.2)",
                            "rgba(255, 206, 86, 0.2)",
                            "rgba(75, 192, 192, 0.2)",
                            "rgba(153, 102, 255, 0.2)",
                            "rgba(255, 159, 64, 0.2)"
                        ],
                        borderColor: [
                            "rgba(255, 99, 132, 1)",
                            "rgba(54, 162, 235, 1)",
                            "rgba(255, 206, 86, 1)",
                            "rgba(75, 192, 192, 1)",
                            "rgba(153, 102, 255, 1)",
                            "rgba(255, 159, 64, 1)"
                        ],
                        borderWidth: 1
                    },
                    {
                        label: "shaum_lainnya",
                        data: [
                                <?php $__currentLoopData = $datamutabaah; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                "<?php echo e($value["shaum_lainnya"]); ?>",
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
                        ],
                        backgroundColor: [
                            "rgba(255, 99, 132, 0.2)",
                            "rgba(54, 162, 235, 0.2)",
                            "rgba(255, 206, 86, 0.2)",
                            "rgba(75, 192, 192, 0.2)",
                            "rgba(153, 102, 255, 0.2)",
                            "rgba(255, 159, 64, 0.2)"
                        ],
                        borderColor: [
                            "rgba(255, 99, 132, 1)",
                            "rgba(54, 162, 235, 1)",
                            "rgba(255, 206, 86, 1)",
                            "rgba(75, 192, 192, 1)",
                            "rgba(153, 102, 255, 1)",
                            "rgba(255, 159, 64, 1)"
                        ],
                        borderWidth: 1
                    }],
                },
                options: {
                    scales: {
                        y: {
                            beginAtZero: true
                        }
                    }
                }
            });
            // End of Grafik Shaum
    
            // Start of Grafik Quran
            var ctx6 = document.getElementById("Chart6").getContext("2d");
            var myChart6 = new Chart(ctx6, {
                type: "line",
                data: {
                    labels: [
                        <?php $__currentLoopData = $datamutabaah; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                "<?php echo e($value["tanggal"]); ?>",
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    ],
                    datasets: [{
                        label: "Tadabbur",
                        data: [
                                <?php $__currentLoopData = $datamutabaah; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                "<?php echo e($value["tadabbur_ayat"]); ?>",
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
                        ],
                        backgroundColor: [
                            "rgba(255, 99, 132, 0.2)",
                            "rgba(54, 162, 235, 0.2)",
                            "rgba(255, 206, 86, 0.2)",
                            "rgba(75, 192, 192, 0.2)",
                            "rgba(153, 102, 255, 0.2)",
                            "rgba(255, 159, 64, 0.2)"
                        ],
                        borderColor: [
                            "rgba(255, 99, 132, 1)",
                            "rgba(54, 162, 235, 1)",
                            "rgba(255, 206, 86, 1)",
                            "rgba(75, 192, 192, 1)",
                            "rgba(153, 102, 255, 1)",
                            "rgba(255, 159, 64, 1)"
                        ],
                        borderWidth: 1
                    },
                    {
                        label: "Jumlah Lembar",
                        data: [
                                <?php $__currentLoopData = $datamutabaah; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                "<?php echo e($value["tilawah_quran"]); ?>",
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
                        ],
                        backgroundColor: [
                            "rgba(255, 99, 132, 0.2)",
                            "rgba(54, 162, 235, 0.2)",
                            "rgba(255, 206, 86, 0.2)",
                            "rgba(75, 192, 192, 0.2)",
                            "rgba(153, 102, 255, 0.2)",
                            "rgba(255, 159, 64, 0.2)"
                        ],
                        borderColor: [
                            "rgba(255, 99, 132, 1)",
                            "rgba(54, 162, 235, 1)",
                            "rgba(255, 206, 86, 1)",
                            "rgba(75, 192, 192, 1)",
                            "rgba(153, 102, 255, 1)",
                            "rgba(255, 159, 64, 1)"
                        ],
                        borderWidth: 1
                    }],
                },
                options: {
                    scales: {
                        y: {
                            beginAtZero: true
                        }
                    }
                }
            });
            // End of Grafik Quran
    
            // Start of Grafik Infaq dan Shodaqoh
            var ctx7 = document.getElementById("Chart7").getContext("2d");
            var myChart7 = new Chart(ctx7, {
                type: "line",
                data: {
                    labels: [
                        <?php $__currentLoopData = $datamutabaah; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                "<?php echo e($value["tanggal"]); ?>",
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    ],
                    datasets: [{
                        label: "Infaq atau Shodaqoh",
                        data: [
                                <?php $__currentLoopData = $datamutabaah; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                "<?php echo e($value["infaq_shadaqah"]); ?>",
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
                        ],
                        backgroundColor: [
                            "rgba(255, 99, 132, 0.2)",
                            "rgba(54, 162, 235, 0.2)",
                            "rgba(255, 206, 86, 0.2)",
                            "rgba(75, 192, 192, 0.2)",
                            "rgba(153, 102, 255, 0.2)",
                            "rgba(255, 159, 64, 0.2)"
                        ],
                        borderColor: [
                            "rgba(255, 99, 132, 1)",
                            "rgba(54, 162, 235, 1)",
                            "rgba(255, 206, 86, 1)",
                            "rgba(75, 192, 192, 1)",
                            "rgba(153, 102, 255, 1)",
                            "rgba(255, 159, 64, 1)"
                        ],
                        borderWidth: 1
                    }],
                },
                options: {
                    scales: {
                        y: {
                            beginAtZero: true
                        }
                    }
                }
            });
            // End of Grafik Infaq dan Shodaqoh
    
            // Start of Grafik Dzikir
            var ctx8 = document.getElementById("Chart8").getContext("2d");
            var myChart8 = new Chart(ctx8, {
                type: "line",
                data: {
                    labels: [
                        <?php $__currentLoopData = $datamutabaah; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                "<?php echo e($value["tanggal"]); ?>",
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    ],
                    datasets: [{
                        label: "Al-Matsurat",
                        data: [
                                <?php $__currentLoopData = $datamutabaah; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                "<?php echo e($value["al_matsurat"]); ?>",
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
                        ],
                        backgroundColor: [
                            "rgba(255, 99, 132, 0.2)",
                            "rgba(54, 162, 235, 0.2)",
                            "rgba(255, 206, 86, 0.2)",
                            "rgba(75, 192, 192, 0.2)",
                            "rgba(153, 102, 255, 0.2)",
                            "rgba(255, 159, 64, 0.2)"
                        ],
                        borderColor: [
                            "rgba(255, 99, 132, 1)",
                            "rgba(54, 162, 235, 1)",
                            "rgba(255, 206, 86, 1)",
                            "rgba(75, 192, 192, 1)",
                            "rgba(153, 102, 255, 1)",
                            "rgba(255, 159, 64, 1)"
                        ],
                        borderWidth: 1
                    },
                    {
                        label: "Lainnya",
                        data: [
                                <?php $__currentLoopData = $datamutabaah; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                "<?php echo e($value["dzikir_lainnya"]); ?>",
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
                        ],
                        backgroundColor: [
                            "rgba(255, 99, 132, 0.2)",
                            "rgba(54, 162, 235, 0.2)",
                            "rgba(255, 206, 86, 0.2)",
                            "rgba(75, 192, 192, 0.2)",
                            "rgba(153, 102, 255, 0.2)",
                            "rgba(255, 159, 64, 0.2)"
                        ],
                        borderColor: [
                            "rgba(255, 99, 132, 1)",
                            "rgba(54, 162, 235, 1)",
                            "rgba(255, 206, 86, 1)",
                            "rgba(75, 192, 192, 1)",
                            "rgba(153, 102, 255, 1)",
                            "rgba(255, 159, 64, 1)"
                        ],
                        borderWidth: 1
                    }],
                },
                options: {
                    scales: {
                        y: {
                            beginAtZero: true
                        }
                    }
                }
            });
    
            // Start of Grafik Nilai Total
            var ctx9 = document.getElementById("Chart9").getContext("2d");
            var myChart9 = new Chart(ctx9, {
                type: "line",
                data: {
                    labels: [
                        <?php $__currentLoopData = $datamutabaah; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                "<?php echo e($value["tanggal"]); ?>",
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    ],
                    datasets: [{
                        label: "Nilai Total",
                        data: [
                                <?php $__currentLoopData = $datamutabaah; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php
                                        $valueSholatWajib = (($item["sholat_subuh"] + $item["sholat_dzuhur"] + $item["sholat_ashar"] + $item["sholat_maghrib"] + $item["sholat_isya"]) / 5) * 0.32;
    
                                        $valueSholatRawatib = (($item["rawatib_subuh"] + $item["rawatib_dzuhur"] + $item["rawatib_ashar"] + $item["rawatib_maghrib"] + $item["rawatib_isya"]) / 5) * 0.16;
    
                                        $valueSholatSunnah = ($item["dhuha"] + $item["tahajud"] + $item["witir"] + $item["tarawih"] + $item["sholat_sunnah_lainnya"]);
                                        
                                        $valueShaum = ($item["shaum_senin_kamis"] + $item["shaum_dawud"] + $item["shaum_ramadhan"] + $item["shaum_lainnya"]) ;
    
                                        if ($valueShaum > 100) {
                                            $valueShaum = 100 * 0.04;
                                        }else {
                                            $valueShaum = 4;
                                        };
    
                                        $valueQuran = ($item["tilawah_quran"] + $item["tadabbur_ayat"]) ;
    
                                        $valueDzikir = ($item["al_matsurat"] + $item["dzikir_lainnya"]) ;
    
                                        $nilaiTotal = $valueSholatWajib + $valueSholatRawatib + $valueSholatSunnah + $valueShaum + $valueQuran + $valueDzikir
                                    ?> 
                                        "<?php echo e($nilaiTotal); ?>",
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        ],
                        backgroundColor: [
                            "rgba(255, 99, 132, 0.2)",
                            "rgba(54, 162, 235, 0.2)",
                            "rgba(255, 206, 86, 0.2)",
                            "rgba(75, 192, 192, 0.2)",
                            "rgba(153, 102, 255, 0.2)",
                            "rgba(255, 159, 64, 0.2)"
                        ],
                        borderColor: [
                            "rgba(255, 99, 132, 1)",
                            "rgba(54, 162, 235, 1)",
                            "rgba(255, 206, 86, 1)",
                            "rgba(75, 192, 192, 1)",
                            "rgba(153, 102, 255, 1)",
                            "rgba(255, 159, 64, 1)"
                        ],
                        borderWidth: 1
                    }],
                },
                options: {
                    scales: {
                        y: {
                            beginAtZero: true
                        }
                    }
                }
            });
            // End of Grafik Nilai Total

            </script>
            <script>
                window.addEventListener("load", window.print());
            </script>

    <!-- JAVASCRIPT -->
	<script src="https://code.iconify.design/1/1.0.7/iconify.min.js"></script>
	<script src="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/js/select2.min.js"></script>
	<script src="/assets/libs/jquery/jquery.min.js"></script>
	<script src="/assets/libs/bootstrap/js/bootstrap.bundle.min.js"></script>
	<script src="/assets/libs/metismenu/metisMenu.min.js"></script>
	<script src="/assets/libs/simplebar/simplebar.min.js"></script>
	<script src="/assets/libs/node-waves/waves.min.js"></script>
	<script src="/assets/libs/waypoints/lib/jquery.waypoints.min.js"></script>
	<script src="/assets/libs/jquery.counterup/jquery.counterup.min.js"></script>
	<!-- App js -->
	<script src="/assets/js/app.js"></script>
</body>
</html>
    
<?php /**PATH C:\laragon\www\eraport-smacm\resources\views/reports/pdf.blade.php ENDPATH**/ ?>